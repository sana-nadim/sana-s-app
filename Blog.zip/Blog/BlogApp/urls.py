
from django.contrib import admin
from django.urls import path,include
from.views import HomeView,PostDetailView,AddPostView,UpdatePostView,DeletePostView


urlpatterns = [
    
    path('',HomeView.as_view(),name="home"),
    path('post/<int:pk>',PostDetailView.as_view(),name="postDetail"),
    path('post/edit/<int:pk>',UpdatePostView.as_view(),name="update_post"),
    path('post/<int:pk>/delete',DeletePostView.as_view(),name="delete_post"),
    path('add_post',AddPostView.as_view(),name="add_post"),
    
    
    
]
